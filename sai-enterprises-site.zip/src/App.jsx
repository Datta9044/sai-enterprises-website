import React from "react";

export default function SaiEnterprisesWebsite() {
  const phone = "+91 90225 06302";
  const rawNumber = "919022506302"; // for tel / WhatsApp links

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center text-white font-bold">SE</div>
            <div>
              <h1 className="text-xl font-semibold">Sai Enterprises</h1>
              <p className="text-sm text-gray-500">Loan Consultancy — Personal | Business | Home | Vehicle</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <a href={`tel:+${rawNumber}`} className="hidden sm:inline-block px-4 py-2 border rounded-lg">Call: {phone}</a>
            <a href={`https://wa.me/${rawNumber}?text=Hello%20Sai%20Enterprises,%20I%20want%20help%20with%20a%20loan`} target="_blank" rel="noreferrer" className="bg-green-500 text-white px-4 py-2 rounded-lg shadow">WhatsApp</a>
          </div>
        </div>
      </header>

      <section className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <h2 className="text-3xl md:text-4xl font-extrabold leading-tight">सोप्या प्रक्रियेत जलद आणि विश्वासार्ह लोन मार्गदर्शन</h2>
          <p className="mt-4 text-gray-600">व्यक्तिगत कर्ज, व्यवसाय कर्ज, कार/टू-व्हीलर कर्ज, गृह कर्ज आणि मालमत्ते विरुद्ध कर्ज — आम्ही सर्व प्रकारचे लोन सल्लागार सेवा पुरवतो. दस्तऐवज तपासणे, सर्वोत्तम बँक शोधणे आणि अर्ज प्रक्रियेत हातेमालो करणे — सर्व तुमच्यासाठी.</p>

          <div className="mt-6 flex gap-3">
            <a href={`tel:+${rawNumber}`} className="inline-block px-5 py-3 border rounded-lg">आता कॉल करा</a>
            <a href={`https://wa.me/${rawNumber}?text=Hi`} target="_blank" rel="noreferrer" className="inline-block px-5 py-3 bg-indigo-600 text-white rounded-lg">WhatsApp वर संपर्क करा</a>
          </div>

          <ul className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-gray-700">
            <li>✓ जलद प्रक्रिया</li>
            <li>✓ कागदपत्रांमध्ये मदत</li>
            <li>✓ कमी व्याजदर शोधणे</li>
            <li>✓ पारदर्शक शुल्क</li>
          </ul>
        </div>

        <div className="aspect-video rounded-lg overflow-hidden shadow">
          <img src="https://source.unsplash.com/featured/?finance,loan" alt="Loan" className="w-full h-full object-cover" />
        </div>
      </section>

      <section className="bg-white py-10">
        <div className="max-w-6xl mx-auto px-6">
          <h3 className="text-2xl font-semibold">आमच्या सेवा</h3>
          <p className="text-gray-500 mt-2">सर्व प्रकारचे लोन सल्लागार व प्रक्रियेत पूर्ण मार्गदर्शन.</p>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[{ title: "Personal Loan", desc: "वेगवेगळ्या उद्देशांसाठी वैयक्तिक लोन" },
              { title: "Business Loan", desc: "SME व उद्योजकांसाठी तातडीने मदत" },
              { title: "Car Loan", desc: "नवीन व सेकंड-हँड वाहनांसाठी कर्ज" },
              { title: "Two-wheeler Loan", desc: "स्कूटर/बाईक कर्ज प्रक्रियेत सहाय्य" },
              { title: "Home Loan", desc: "गृह खरेदी व नूतनीकरणासाठी मार्गदर्शन" },
              { title: "Loan Against Property", desc: "मालमत्ता-आधारित कर्जाचे सर्वोत्तम विकल्प" }].map((s) => (
              <div key={s.title} className="p-5 border rounded-lg bg-gray-50">
                <h4 className="font-semibold">{s.title}</h4>
                <p className="text-sm text-gray-600 mt-2">{s.desc}</p>
                <div className="mt-4">
                  <a href={`https://wa.me/${rawNumber}?text=I%20need%20help%20with%20${encodeURIComponent(s.title)}`} target="_blank" rel="noreferrer" className="text-sm">Connect on WhatsApp →</a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-10">
        <h3 className="text-2xl font-semibold">प्रक्रिया कशी आहे?</h3>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-5 bg-white border rounded-lg">
            <h4 className="font-semibold">1. संपर्क करा</h4>
            <p className="text-sm text-gray-600 mt-2">निवडलेला सेवा प्रकार कळवा — आम्ही संपर्कात राहू.</p>
          </div>
          <div className="p-5 bg-white border rounded-lg">
            <h4 className="font-semibold">2. दस्तऐवज तपासणी</h4>
            <p className="text-sm text-gray-600 mt-2">आवश्यक कागदपत्रे एकत्र करा — आम्ही ते तपासून सर्वोत्तम पर्याय सुचवू.</p>
          </div>
          <div className="p-5 bg-white border rounded-lg">
            <h4 className="font-semibold">3. अर्ज व प्रक्रिया</h4>
            <p className="text-sm text-gray-600 mt-2">अर्ज पूर्ण करून बँक/आर्थिक संस्थेमध्ये पाठवले जाईल — प्रगती तुम्हाला कळवली जाईल.</p>
          </div>
        </div>
      </section>

      <section className="bg-indigo-50 py-10">
        <div className="max-w-4xl mx-auto px-6">
          <h3 className="text-2xl font-semibold">संपर्क करा</h3>
          <p className="text-gray-600 mt-2">किंवा थेट कॉल / व्हाट्सअप करा.</p>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <div className="p-4 bg-white border rounded-lg">
                <p className="text-sm">Company: <strong>Sai Enterprises</strong></p>
                <p className="text-sm">Phone: <a href={`tel:+${rawNumber}`} className="underline">{phone}</a></p>
                <p className="text-sm">WhatsApp: <a href={`https://wa.me/${rawNumber}`} target="_blank" rel="noreferrer" className="underline">Start chat</a></p>
              </div>

              <div className="p-4 bg-white border rounded-lg">
                <p className="text-sm">Office Timing: Mon - Sat, 10:00 AM - 7:00 PM</p>
                <p className="text-sm mt-2">Address: (Add your office address here)</p>
              </div>
            </div>

            <form className="p-6 bg-white border rounded-lg space-y-4" onSubmit={(e) => { e.preventDefault(); window.location.href = `https://wa.me/${rawNumber}?text=${encodeURIComponent('Hello Sai Enterprises, I am '+ (e.target.name?.value || 'a customer') +'. I need help with: '+ (e.target.service?.value || 'General enquiry') +'. My phone: '+ (e.target.phone?.value || '') )}`; }}>
              <div>
                <label className="text-sm">नाव</label>
                <input name="name" className="w-full mt-1 p-2 border rounded" placeholder="तुमचे नाव" />
              </div>
              <div>
                <label className="text-sm">फोन</label>
                <input name="phone" className="w-full mt-1 p-2 border rounded" placeholder="+91 9xxxxxxxxx" />
              </div>
              <div>
                <label className="text-sm">सेवा निवडा</label>
                <select name="service" className="w-full mt-1 p-2 border rounded">
                  <option>Personal Loan</option>
                  <option>Business Loan</option>
                  <option>Car Loan</option>
                  <option>Two-wheeler Loan</option>
                  <option>Home Loan</option>
                  <option>Loan Against Property</option>
                </select>
              </div>

              <div className="flex gap-3">
                <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">Send via WhatsApp</button>
                <a href={`tel:+${rawNumber}`} className="px-4 py-2 border rounded">Call Now</a>
              </div>
            </form>
          </div>
        </div>
      </section>

      <footer className="bg-white mt-10 border-t">
        <div className="max-w-6xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-600">© {new Date().getFullYear()} Sai Enterprises. All rights reserved.</p>
          <div className="flex items-center gap-3 text-sm">
            <a href={`https://wa.me/${rawNumber}`} target="_blank" rel="noreferrer" className="underline">WhatsApp</a>
            <a href={`tel:+${rawNumber}`} className="underline">{phone}</a>
          </div>
        </div>
      </footer>
    </div>
  );
}