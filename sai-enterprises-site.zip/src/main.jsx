import React from 'react';
import { createRoot } from 'react-dom/client';
import SaiEnterprisesWebsite from './App';
import './index.css';

createRoot(document.getElementById('root')).render(<SaiEnterprisesWebsite />);